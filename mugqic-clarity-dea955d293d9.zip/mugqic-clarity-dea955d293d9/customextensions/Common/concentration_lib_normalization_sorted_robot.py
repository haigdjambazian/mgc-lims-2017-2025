'''
Created on August 2, 2018

@author: Alexander Mazur, alexander.mazur@gmail.com
    update 2019_01_03:
        - human sorting for destination plate + destination position
    update 2018_08_14:
        - print_plates_info_table added to create mapping table file
        - added  

Note: 
'''
script_version="2019_04_18"

__author__ = 'Alexander Mazur'


import os, argparse, shutil, logging, math, os
import numpy as np
import numpy.polynomial.polynomial as poly
import time
import requests
import re, xml
from xml.dom.minidom import parseString
import xml.etree.ElementTree as ET



  

user=''
psw=''
#BASE_URI='https://bravotestapp.genome.mcgill.ca/api/v2/'
script_dir=os.path.dirname(os.path.realpath(__file__))
HOSTNAME = "bravotestapp.genome.mcgill.ca"
VERSION = ""
BASE_URI = ""
DEBUG = False
QC_status={'PASS':"PASSED", 'FAIL':"FAILED"}
DestName='TubeDst'


parser = argparse.ArgumentParser(description='Calculate normalized Concentration values per sample')
parser.add_argument('-stepURI_v2',default='', help='stepURI_v2 from WebUI')
#parser.add_argument('-processLuid',default='', help='processLuid from WebUI')
parser.add_argument('-user_psw',default='', help='API user and password')
parser.add_argument('-ar',default='r', help='Analyte or ResultFile ')
parser.add_argument('-ComponentLuids',default='', help='LUIDs for the generated files ')
parser.add_argument('-qc',default='', help='thake into account QC status <0|1>')
parser.add_argument('-reports',default='1', help='print or not print reports <0|1>')



'''
{stepURI:v2}
http://localhost:9080/api/v2/steps/24-1297
-stepURI_v2 https://bravotestapp.genome.mcgill.ca/api/v2/steps/24-13716
-processLuid 24-13716
'''

global bReports
args = parser.parse_args()
stepURI_v2=args.stepURI_v2
user_psw = args.user_psw
Analyte_Result=args.ar
ComponentLuids=args.ComponentLuids
qc=args.qc
bReports=args.reports


if Analyte_Result.upper() =='R':
    Analyte_Result="ResultFile"
else:
    Analyte_Result="Analyte"

'''
    Add username and password from API
'''
if (user_psw):
    (user,psw)=user_psw.split(':')

LUIDs=ComponentLuids.split(" ")
sDataPath='/data/glsftp/clarity/'
sSubFolderName=sDataPath+time.strftime('%Y/%m/')
hProjects={}
containers_arr={}
dest_containers_arr={}
ArtifactsLUID=[]
destArtifactsLUID=[]
Sample_Concentration={}
container_ID=''
sDestConcentration=''
sDestVolume=''
Affy_Controls={'Axiom_gDNA103':"CtrlRack1",'CEPH1463-02':"CtrlRack2",'Negative_Control':"Trough1","NA12878":"CtrlRack2"}
#Affy_Controls={'Axiom gDNA103':"CtrlRack1",'CEPH1463-02':"CtrlRack2",'Negative Control':"Trough1"}



#processLuid = processLuid.replace('24-','')


'''
Affy Controls
Name    Src ID    Src Coord
Axiom gDNA 103    CtrlRack1    1
Axiom gDNA 103    CtrlRack1    3
Axiom gDNA 103    CtrlRack1    4
Axiom gDNA 103    CtrlRack1    5
CEPH1347-2    CtrlRack2    9
CEPH1347-2    CtrlRack2    9
CEPH1347-2    CtrlRack2    9
CEPH1347-2    CtrlRack2    9
CEPH1347-2    CtrlRack2    9
CEPH1347-2    CtrlRack2    9
CEPH1347-2    CtrlRack2    9
Negative Control    Trough1    1
Negative Control    Trough1    1
Negative Control    Trough1    1 



'''
def setupGlobalsFromURI( uri ):

    global HOSTNAME
    global VERSION
    global BASE_URI
    global ProcessID

    tokens = uri.split( "/" )
    HOSTNAME = "/".join(tokens[0:3])
    VERSION = tokens[4]
    BASE_URI = "/".join(tokens[0:5]) + "/"
    ProcessID=tokens[-1]

    if DEBUG is True:
        print (HOSTNAME)
        print (BASE_URI)


def get_artifacts_array(processLuid):

    global user,psw,ArtifactsLUID

    ## get the process XML
    pURI = BASE_URI + "processes/" + processLuid
    #print(pURI)
    pXML= requests.get(pURI, auth=(user, psw), verify=True)
    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}
    #print (pXML.content)
    pDOM = parseString( pXML.content )

    ## get the individual resultfiles outputs
    nodes = pDOM.getElementsByTagName( "input" )
    for input in nodes:
        iURI = input.getAttribute( "post-process-uri" )
        iLUID = input.getAttribute( "limsid" )
        if iLUID not in ArtifactsLUID:
            ArtifactsLUID.append( iLUID )

def get_dest_artifacts_array(processLuid):
    global user,psw,destArtifactsLUID

    pURI = BASE_URI + "processes/" + processLuid
    pXML= requests.get(pURI, auth=(user, psw), verify=True)
    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}

    pDOM = parseString( pXML.content )

    ## get the individual resultfiles outputs
    nodes = pDOM.getElementsByTagName( "output" )
    for output in nodes:
        iURI = output.getAttribute( "uri" )
        oLUID = output.getAttribute( "limsid" )
        oType = output.getAttribute( "output-type" )
        ogType = output.getAttribute( "output-generation-type" )
              
        if oType == Analyte_Result and ogType == "PerInput":
            if oLUID not in destArtifactsLUID:
                destArtifactsLUID.append( oLUID )


def prepare_artifacts_batch(ArtifactsLUID):
    global BASE_URI
    lXML = []
    lXML.append( '<?xml version="1.0" encoding="utf-8"?><ri:links xmlns:ri="http://genologics.com/ri">' )
    
    for art in ArtifactsLUID:
        scURI = BASE_URI+'artifacts/'+art
        lXML.append( '<link uri="' + scURI + '" rel="artifacts"/>' )        

    lXML.append( '</ri:links>' )
    lXML = ''.join( lXML ) 

    return lXML

def prepare_artifacts_batch_from_map_io(map_io, sIO):
    global BASE_URI
    lXML = []
    lXML.append( '<?xml version="1.0" encoding="utf-8"?><ri:links xmlns:ri="http://genologics.com/ri">' )
    for art in map_io:
        iArt,oArt=art.split("xxx")
        if (sIO=='input') or (sIO==''):
            art=iArt

        if sIO=='output':
            art=oArt
            
        scURI = BASE_URI+'artifacts/'+art
        lXML.append( '<link uri="' + scURI + '" rel="artifacts"/>' )        
    lXML.append( '</ri:links>' )
    lXML = ''.join( lXML ) 

    return lXML  

def retrieve_artifacts(sXML):
    global BASE_URI, user,psw
    sURI=BASE_URI+'artifacts/batch/retrieve'
    headers = {'Content-Type': 'application/xml'}
    r = requests.post(sURI, data=sXML, auth=(user, psw), verify=True, headers=headers)

    return r.content
def get_container_name(containerLUID):
    
    containerURI=BASE_URI+'containers/'+containerLUID
    r = requests.get(containerURI, auth=(user, psw), verify=True)    
    rDOM = parseString(r.content )
    node =rDOM.getElementsByTagName('name')
    ss = node[0].firstChild.nodeValue
    return ss

def get_org_samples_array(sXML):
    global sampleURIs
    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}
    root = ET.fromstring(sXML)
    ss=''
    i=1
    sampleURIs=[]
    for child in root.findall('art:artifact',nss):
        #print (child)
        limsid=child.attrib['limsid']
        name = child.find('name')
        artifact_name=name.text
        #print (artifact_name)
        parentID=child.find('parent-process')
        sLocation=child.find('location')
        container=sLocation.find('container')
        sample= child.find('sample')
        sample_ID=sample.attrib['limsid']
        sample_URI=sample.attrib['uri']
        if sample_URI not in sampleURIs:
           sampleURIs.append( sample_URI)
    return

def prepare_samples_batch(sampleURIs):
    lXML = []
    lXML.append( '<?xml version="1.0" encoding="utf-8"?><ri:links xmlns:ri="http://genologics.com/ri">' )
    
    for art in sampleURIs:
        lXML.append( '<link uri="' + art + '" rel="samples"/>' )        

    lXML.append( '</ri:links>' )
    lXML = ''.join( lXML ) 

    return lXML 

def retrieve_samples(sXML):
    global BASE_URI, user,psw
    sURI=BASE_URI+'samples/batch/retrieve'

    headers = {'Content-Type': 'application/xml'}
    r = requests.post(sURI, data=sXML, auth=(user, psw), verify=True, headers=headers)
    
    return r.content




def get_phisical_position(sAlphaNumPosition):
    
    s=sAlphaNumPosition[0].upper()
    sASCII= ord(s)
    sDigit=sAlphaNumPosition[1:].upper()
    sDigit=sDigit.replace(':0','')
    sDigit=sDigit.replace(':','') 
    
    sPhPos=(int(sASCII)-64)+(int(sDigit)-1)*8
    
    return sPhPos
    
def get_process_UDFs(ProcessID):
    global user,psw, hProjects,sDestConcentration, sDestVolume, sControls, sThreshold,sConcentrationFrom, sTarget, iQuantity,iVolCtrl
    processURI=BASE_URI+'processes/'+ProcessID
    
    r = requests.get(processURI, auth=(user, psw), verify=True)
    rDOM = parseString(r.content)
    
    sDestConcentration=getUDF(rDOM, 'Destination Concentration (ng/ul)')
    sDestVolume=getUDF(rDOM, 'Destination Volume (ul)')
    sControls=getUDF(rDOM, 'Controls')
    sThreshold=getUDF(rDOM, 'Threshold, ng/ul')
    sConcentrationFrom=getUDF(rDOM, 'Concentration from') 
    sTarget= getUDF(rDOM, 'Target')
    iQuantity= getUDF(rDOM, 'Total Quantity for Pool (ng)')
    iVolCtrl=getUDF(rDOM, 'VolCtrl')
        
    return sDestConcentration, sDestVolume, sControls, sThreshold,sConcentrationFrom, sTarget, iQuantity, iVolCtrl    

def calculate_dilution(sSrcConcentration,sDestConcentration, sDestVolume,sSize):
    
    sSrcConcentration=get_ng_ul(sSrcConcentration,sSize)
    if sSrcConcentration==0:
        sSrcConcentration=0.33
    
    delta=0
    if (sSrcConcentration == 999):
        x=20
        w=0
    else:
        
        if (iVolCtrl) and float(iVolCtrl)>0:
            delta=float(iVolCtrl)
        try:    
            if (sTarget == "Quantity"):
                x=float(iQuantity)/float(sSrcConcentration)
                
            else:
                x=float(sDestConcentration)*float(sDestVolume)/float(sSrcConcentration)
        except:
            print ('Can"t find concentration data, please check and try again')
            exit(111)    
        w=float(sDestVolume)-x
        
    return x,w,delta
    
def get_concentration_from_artifacts(sXML):    
    global Sample_Concentration

    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}
    
    
    
    root = ET.fromstring(sXML)
    ss=''
    
    sHeader='Src ID\tSrc Coord\tDst ID\tDst Coord\tDiluent Vol\tSample Vol\tCoord\tSample Name'
 
    proj="XXX"
    i=1
    
    for child in root.findall('art:artifact',nss):
        #print (child)
        limsid=child.attrib['limsid']
        name = child.find('name')
        artifact_name=name.text
        #print (artifact_name)
        parentID=child.find('parent-process')
        sLocation=child.find('location')
        container=sLocation.find('container')
        
        pos=sLocation.find('value')
        well_position=pos.text
        #print (well_position)
        if len(well_position)==3:
            well_position=well_position.replace(':','0')
        else:
            well_position=well_position.replace(':','')
        sample= child.find('sample')
        sample_ID=sample.attrib['limsid']
        metaProj=sample.attrib['limsid'][0:6]

        
        containerID=container.attrib['limsid']
        containerName=get_container_name(containerID)
        isControlContainer=child.find('control-type')
        
        #if (containerID not in containers_arr) and (isControlContainer is None):
        #   containers_arr[containerID] = "Src"+str(i)
        #   i+=1
        
        
        
        
        
        if (sConcentrationFrom == "Submitted Sample") and (isControlContainer is None): 
            Sample_Concentration[sample_ID]="xxx__"+well_position+"__"+containers_arr[containerID]+"__"+artifact_name+"__"+containerID+"__"+containerName        
        sSize='99'
        sLibVolume='-999'
        sLibConcUnit='xxx'
        udf_child = child.findall('udf:field', nss)
        
        for sUDF in udf_child:
            if sUDF.attrib['name'] == 'Conc. Units':
                sLibConcUnit=sUDF.text            
            if sUDF.attrib['name'] == 'Library Volume (ul)':
                sLibVolume=sUDF.text
            if sUDF.attrib['name'] == 'Size (bp)':
                sSize=sUDF.text
            if sUDF.attrib['name'] == 'Concentration':
                sConcentration=sUDF.text
                
        if sample_ID not in Sample_Concentration:
            Sample_Concentration[sample_ID]=sConcentration+"__"+well_position+"__"+containers_arr[containerID]+"__"+artifact_name+"__"+containerID+"__"+containerName+"__"+sSize+"__"+sLibVolume+"__"+sLibConcUnit
            #print (sample_ID+"\t"+sConcentration+"\t"+well_position+"\t"+containers_arr[containerID]+"\t"+artifact_name)
            
           # else:

                
                
        
        
        #print (limsid+"\t"+name)


    return



def get_concentration_from_org_samples(sXML):    
    global containers_arr, Sample_Concentration
    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project", 'smp':"http://genologics.com/ri/sample"}
    root = ET.fromstring(sXML)
    ss=''
    
    proj="XXX"
    i=1
    for child in root.findall('smp:sample',nss):
        #print (child)
        sample_ID=child.attrib['limsid']
        name = child.find('name')
        artifact_name=name.text
        udf_child = child.findall('udf:field', nss)
        for sUDF in udf_child:
            if sUDF.attrib['name'] == 'Sample Conc.':
                sConcentration=sUDF.text
                if sample_ID in Sample_Concentration:
                    artifact_concentration=Sample_Concentration[sample_ID]
                    artifact_concentration=artifact_concentration.replace('xxx',sConcentration)
                    Sample_Concentration[sample_ID]= artifact_concentration
                    #print (sample_ID+"\t"+sConcentration+"\t"+well_position+"\t"+containers_arr[containerID]+"\t"+artifact_name)
            

    return

def old_get_well_position_from_artifacts(sXML):    
    global dest_containers_arr,Affyreagent_counter

    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}
    pDOM = parseString( sXML )
    
    #print (sXML)
    root = ET.fromstring(sXML)
    ss=''
    
    sHeader='Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol,Coord,Sample Name'
    
    
    print(sHeader)
    proj="XXX"
    sOUT="Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol,Coord,Sample Name, Concentration_Org\n"
    i=1
    Affyreagent_counter =1
    '''
     get all destination containers and assign Dst index in sorted oreder
    '''
    
    for child in root.findall('art:artifact',nss):
        sLocation=child.find('location')
        container=sLocation.find('container')
        dest_containerID=container.attrib['limsid']    
        if dest_containerID not in dest_containers_arr:
           dest_containers_arr[dest_containerID] = ""
           
    j=1
    for contr in sorted(dest_containers_arr):
        dest_containers_arr[contr]="Dst"+str(j)
        j +=1
    
    #f_out=open(LUIDs[1]+"_log.csv","w")
    for child in root.findall('art:artifact',nss):
        #print (child)
        limsid=child.attrib['limsid']
        name = child.find('name')
        dest_sample_name=name.text
        parentID=child.find('parent-process')
        sLocation=child.find('location')
        container=sLocation.find('container')
        
        pos=sLocation.find('value')
        well_position=pos.text
        #print (well_position)
        if len(well_position)==3:
            well_position=well_position.replace(':','0')
        else:
            well_position=well_position.replace(':','')
        sample= child.find('sample')
        
        metaProj=sample.attrib['limsid'][0:6]
        dest_containerID=container.attrib['limsid']
        sRobotPosition=get_phisical_position(well_position)
        '''
        commented due to dest_containers_arr has been created and sorted by ID earlier on top side 
        
        
        if dest_containerID not in dest_containers_arr:
           dest_containers_arr[dest_containerID] = "Dst"+str(i)
           i+=1
        '''   
        sConcentration="Ctrl"  
        sample_ID=sample.attrib['limsid']
        sSRCPosition='1'
        SrcID='CtrlRack2'
        Concentration_org=0
        sSRCPosition='1'        
        if sample_ID not in Sample_Concentration:
            sConcentration=999
        else:
            (Concentration_org,src_position,SrcID, Sample_Name, containerID,containerName)=Sample_Concentration[sample_ID].split('__')
            sConcentration=Concentration_org
            sSRCPosition=get_phisical_position(src_position)

        
        (x,w, delta)=calculate_dilution(sConcentration,sDestConcentration, sDestVolume)
        #print ("########\n"+sDestVolume+":"+sConcentration+"="+str(x)+"; w="+str(w)+"\n########\n")
        if w <0:
            w=0
            #x=sDestConcentration
        '''
        if float(x) < 2:
            w=18
            x=2
        '''                            
        DstID=dest_containers_arr[dest_containerID]
#        print (Sample_Name)
        if dest_sample_name in Affy_Controls:
            #print (dest_sample_name+"\t"+str(Affyreagent_counter))
            controlNode=child.find("control-type")
            controlURI=controlNode.attrib["uri"]
            controlConcentration=get_control_concentration(controlURI)
            SrcID=Affy_Controls[dest_sample_name]
            sample_ID=limsid+"_"+sample_ID
            if (dest_sample_name == 'CEPH1463-02'):
                sSRCPosition=9
                
            if (dest_sample_name == 'NA12878'):
                #sSRCPosition=DstID[-1]
                Affyreagent_counter +=1
                (x,w,delta)=calculate_dilution(controlConcentration,sDestConcentration, sDestVolume)
                
                '''
                    Negative_Control w=20, x=0
                '''                
            if (dest_sample_name == 'Negative_Control'):
                w=20
                x=0            
        

        sOUT = sOUT + SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(w)+","+str(x)+','+well_position+','+sample_ID+','+str(Concentration_org)+'\n'

        #if (float(Concentration_org) >= float(sThreshold)) or (dest_sample_name in Affy_Controls):
        print(SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(w)+","+str(x)+','+well_position+','+sample_ID)
    
    #f_out.write(sOUT)
    #f_out.close()
        
    return

def get_well_position_from_artifacts(sXML):    
    global dest_containers_arr,Affyreagent_counter,dest_sort_hash,destRobot_hash

    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}
    pDOM = parseString( sXML )
    
    #print (sXML)
    root = ET.fromstring(sXML)
    ss=''
    dest_sort_hash={}
    destRobot_hash={}
    #sHeader='Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol,Coord,Sample Name'
    sHeader='Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol'
    sReport=sHeader
    
    
    #print(sHeader)
    proj="XXX"
    sOUT="Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol,Coord,Sample Name,Concentration_Org,LibConcUnits,Concentration_(ng/ul),Size_(bp),Library_Volume_Used_(ul),Pooling_Fraction,Pooling_Group,LibVolumeLeftOver,QCStatus,qcUpdateStatus\n"
    i=1
    kk=1
    Affyreagent_counter =1
    '''
     get all destination containers and assign Dst index in sorted oreder
    '''
    
    for child in root.findall('art:artifact',nss):
        artLUID=child.attrib['limsid']
        sLocation=child.find('location')
        container=sLocation.find('container')
        dest_containerID=container.attrib['limsid'] 
        meta_dest_containerID=int(dest_containerID.replace("27-",""))   
        udfNode=child.findall('udf:field', nss)
        for udfKey in udfNode:
            if udfKey.attrib['name'] == 'Pooling Group':
                udfPoolingGroup=udfKey.text
                if udfPoolingGroup not in destRobot_hash:
                    destRobot_hash[udfPoolingGroup]=(kk,dest_containerID)
                    kk +=1
                             
        if meta_dest_containerID not in dest_containers_arr:
           dest_containers_arr[meta_dest_containerID] = ""
           
    j=1
    
    for contr in sorted(dest_containers_arr):
        dest_containers_arr[contr]="Dst"+str(j)
        j +=1
    j=1
    temp_hash={}
    for key in sorted(destRobot_hash):
        id,dest_containerID=destRobot_hash[key]
        temp_hash[key]=(j,dest_containerID)
        #print (key,j,dest_containerID)
        j+=1
    destRobot_hash={}
    destRobot_hash.update(temp_hash)    
    
    #f_out=open(LUIDs[1]+"_log.csv","w")
    for child in root.findall('art:artifact',nss):
        #print (child)
        limsid=child.attrib['limsid']
        name = child.find('name')
        dest_sample_name=name.text
        qcFlag=child.find('qc-flag').text
        parentID=child.find('parent-process')
        sLocation=child.find('location')
        container=sLocation.find('container')
        
        pos=sLocation.find('value')
        well_position=pos.text
        #print (well_position)
        if len(well_position)==3:
            well_position=well_position.replace(':','0')
        else:
            well_position=well_position.replace(':','')
        sample= child.find('sample')
        
        metaProj=sample.attrib['limsid'][0:6]
        dest_containerID=container.attrib['limsid']
        sRobotPosition=get_phisical_position(well_position)
        '''
        commented due to dest_containers_arr has been created and sorted by ID earlier on top side 
        
        
        if dest_containerID not in dest_containers_arr:
           dest_containers_arr[dest_containerID] = "Dst"+str(i)
           i+=1
        '''   
        sConcentration="Ctrl"  
        sample_ID=sample.attrib['limsid']
        sSRCPosition='1'
        SrcID='CtrlRack1'
        Concentration_org=0
        sSRCPosition='1'        
        sPoolingFraction="N/A"
        sPoolingGroup="N/A"
        
        udf_child = child.findall('udf:field',nss)
        indexQC="Fail"
        for sUDF in udf_child:
            
            if sUDF.attrib['name'] == 'Pooling Fraction':
                sPoolingFraction=sUDF.text            
            if sUDF.attrib['name'] == 'Pooling Group':
                sPoolingGroup=sUDF.text
            if sUDF.attrib['name'] == 'Pooling QC':
                indexQC=sUDF.text            
            

        
        if sample_ID not in Sample_Concentration:
            sConcentration=999
        else:
            (Concentration_org,src_position,SrcID, Sample_Name, containerID,containerName,sSize, sLibVolume,sLibConcUnit)=Sample_Concentration[sample_ID].split('__')
            sConcentration=Concentration_org
            sSRCPosition=get_phisical_position(src_position)

        
        (x,w,delta)=calculate_dilution(sConcentration,sDestConcentration, sDestVolume, sSize)
        #if w <0:
        #    w=0
        #    x=sDestConcentration
        '''    
        if float(x) < 2:
            x=2
            w=float(sDestVolume)-x
        '''     
        meta_dest_containerID=int(dest_containerID.replace("27-",""))                           
        DstID=dest_containers_arr[meta_dest_containerID]
#        print (Sample_Name)
        if dest_sample_name in Affy_Controls:
            #print (dest_sample_name+"\t"+str(Affyreagent_counter))
            SrcID=Affy_Controls[dest_sample_name]
            sample_ID=limsid+"_"+sample_ID
            if (dest_sample_name == 'CEPH1463-02'):
                sSRCPosition=9
                
            if (dest_sample_name == 'Axiom_gDNA103'):
            #if (dest_sample_name == 'Axiom gDNA103'):                  
                #sSRCPosition=str(Affyreagent_counter)
                sSRCPosition=DstID[-1]
                Affyreagent_counter +=1
                '''
                    Negative_Control w=20, x=0
                '''                
            if (dest_sample_name == 'Negative_Control'):
                w=20
                x=0            

        
        if (iVolCtrl) and (float(iVolCtrl) >0):
            w=w-delta        
        
        #print (x,w,delta)
        if float(w)<0:
            w='0'
        
        new_w='%.2f' % float(w)
        new_x='%.2f' % float(x)
        concentrationNgUl=get_ng_ul(Concentration_org, sSize)


        #if (float(Concentration_org) >= float(sThreshold)) or (dest_sample_name in Affy_Controls):
        #print(SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(w)+","+str(x)+','+well_position+','+sample_ID)

        
        
        if sRobotPosition<10:
            new_sRobotPosition="0"+str(sRobotPosition)
        else:
            new_sRobotPosition=str(sRobotPosition)
        new_DstID=DstID.replace("Dst","")
        if len(new_DstID) <2:
            new_DstID="0"+new_DstID
        
        #dest_index=DestName+'_'+str(destRobot_hash[sPoolingGroup])
        
        DstID=DestName
        sRobotPosition,sDestContainerID = destRobot_hash[sPoolingGroup]
        if sRobotPosition<10:
            newRobotPos="0"+str(sRobotPosition)
        else:
            newRobotPos=str(sRobotPosition)
        if (sSRCPosition)<10:
            newSRCPos="0"+str(sSRCPosition)
        else:
            newSRCPos=str(sSRCPosition)            
            
        dest_index=DstID+"_"+newRobotPos+"_"+SrcID+"_"+newSRCPos
        
        QCStatus="Fail"
        if sLibVolume !='N/A':
            sLibVolumeLeftOver=float(sLibVolume)-float(new_x)*float(sPoolingFraction)
            sLibVolumeRequired=float(new_x)*float(sPoolingFraction)
            if sLibVolumeLeftOver>=0:
                QCStatus="Pass"
        else:
            sLibVolumeLeftOver=-999
            sLibVolumeRequired=-999

        qcUpdateStatus="N/A"  
        rVolumeStatus=update_artifact_post(limsid, 'Volume QC',QCStatus, '')  
        '''
        update Library Volume to Use
        '''
        r=update_artifact_post(limsid, 'Library Volume To Use (ul)',sLibVolumeRequired, '')
        sUDFArtifactUpdateStatus=str(r.status_code)        
        
        '''
        if qcFlag=="UNKNOWN":
            qcUpdateStatus=str(update_QC_flag(limsid, QCStatus.upper() ).status_code)
            qcFlag=QC_status[QCStatus.upper()]
        '''    
        
        
        #print(str( qcUpdateStatus.status_code))
        #if (QCStatus=="Pass") or (qcFlag=="PASSED"):
        '''
        For LIbrary Norm new_w=0
        
        '''
        new_w=0
        '''
        if  (qcFlag=="PASSED") and (indexQC=="Pass"):
            if QCStatus == "Fail":
                sLibVolumeRequired=float(sLibVolume)
            r=update_artifact_post(limsid, 'Library Volume To Use (ul)',sLibVolumeRequired, '')
            sUDFArtifactUpdateStatus=str(r.status_code)
        else:
            r=update_artifact_post(limsid, 'Library Volume To Use (ul)','', '')
            sUDFArtifactUpdateStatus=str(r.status_code)            
            #sUDFArtifactUpdateStatus="N/A"
        '''    

        
        sOUT = sOUT + SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(new_w)+","+str(sLibVolumeRequired)+','+well_position+','+sample_ID+','
        sOUT = sOUT + str(Concentration_org)+','+sLibConcUnit+','+str(concentrationNgUl)+','+sSize+','+sLibVolume+','+sPoolingFraction+','+sPoolingGroup+','+str(sLibVolumeLeftOver)+','+QCStatus+',qc='+str(qcUpdateStatus)+' '+limsid+' updStat='+sUDFArtifactUpdateStatus+'\n'
        
        if (QCStatus=="Pass"):
        #if  (qcFlag=="PASSED") and (indexQC=="Pass"):
            #if QCStatus == "Fail":
            #    sLibVolumeRequired=float(sLibVolume)
                        
            if dest_index not in dest_sort_hash:
                #dest_sort_hash[dest_index]=SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(new_w)+","+str(sLibVolumeRequired)+','+well_position+','+sample_ID
                dest_sort_hash[dest_index]=SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(new_w)+","+str(sLibVolumeRequired)
        
        if (iVolCtrl) and (float(iVolCtrl) >0):            
            sOUT = sOUT + 'CtrlRack1,1,'+DstID+','+str(sRobotPosition)+',0,'+str(delta)+','+well_position+','+sample_ID+',999\n'
            ctrl_index='CtrlRack1_'+new_sRobotPosition         
            if ctrl_index not in dest_sort_hash:
                #dest_sort_hash[ctrl_index]='CtrlRack1,1,'+DstID+','+str(sRobotPosition)+',0,'+str(delta)+','+well_position+','+sample_ID
                dest_sort_hash[ctrl_index]='CtrlRack1,1,'+DstID+','+str(sRobotPosition)+',0,'+str(delta)
        
 
 
    # print a sorted in human order 
    for key in sorted(dest_sort_hash):
        #print (dest_sort_hash[key])
        sReport +=dest_sort_hash[key]+"\n" 
    if bReports=='1':
        f_out=open(LUIDs[1]+"_log.csv","w")       
        f_out.write(sOUT)
        f_out.close()
        
    return sReport


def get_qc_well_position_from_artifacts(sXML):    
    global dest_containers_arr,Affyreagent_counter,dest_sort_hash,destRobot_hash

    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}
    pDOM = parseString( sXML )
    
    #print (sXML)
    root = ET.fromstring(sXML)
    ss=''
    dest_sort_hash={}
    destRobot_hash={}
    #sHeader='Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol,Coord,Sample Name'
    sHeader='Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol\n'
    sReport=sHeader
    
    
    #print(sHeader)
    proj="XXX"
    sOUT="Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol,Coord,Sample Name,Concentration_Org,LibConcUnits,Concentration_(ng/ul),Size_(bp),Library_Volume_Used_(ul),Pooling_Fraction,Pooling_Group,LibVolumeLeftOver,QCStatus,qcUpdateStatus\n"
    i=1
    kk=1
    Affyreagent_counter =1
    '''
     get all destination containers and assign Dst index in sorted oreder
    '''
    
    for child in root.findall('art:artifact',nss):
        artLUID=child.attrib['limsid']
        sLocation=child.find('location')
        container=sLocation.find('container')
        dest_containerID=container.attrib['limsid'] 
        meta_dest_containerID=int(dest_containerID.replace("27-",""))   
        udfNode=child.findall('udf:field', nss)
        for udfKey in udfNode:
            if udfKey.attrib['name'] == 'Pooling Group':
                udfPoolingGroup=udfKey.text
                if udfPoolingGroup not in destRobot_hash:
                    destRobot_hash[udfPoolingGroup]=(kk,dest_containerID)
                    kk +=1
                             
        if meta_dest_containerID not in dest_containers_arr:
           dest_containers_arr[meta_dest_containerID] = ""
           
    j=1
    
    for contr in sorted(dest_containers_arr):
        dest_containers_arr[contr]="Dst"+str(j)
        j +=1
    j=1
    
    temp_hash={}
    for key in sorted(destRobot_hash):
        id,dest_containerID=destRobot_hash[key]
        temp_hash[key]=(j,dest_containerID)
        #print (key,j,dest_containerID)
        j+=1
        
    destRobot_hash={}
    destRobot_hash.update(temp_hash)    
    
    
    for child in root.findall('art:artifact',nss):
        #print (child)
        limsid=child.attrib['limsid']
        name = child.find('name')
        dest_sample_name=name.text
        qcFlag=child.find('qc-flag').text
        parentID=child.find('parent-process')
        sLocation=child.find('location')
        container=sLocation.find('container')
        
        pos=sLocation.find('value')
        well_position=pos.text
        #print (well_position)
        if len(well_position)==3:
            well_position=well_position.replace(':','0')
        else:
            well_position=well_position.replace(':','')
        sample= child.find('sample')
        
        metaProj=sample.attrib['limsid'][0:6]
        dest_containerID=container.attrib['limsid']
        sRobotPosition=get_phisical_position(well_position)
        '''
        commented due to dest_containers_arr has been created and sorted by ID earlier on top side 
        
        
        if dest_containerID not in dest_containers_arr:
           dest_containers_arr[dest_containerID] = "Dst"+str(i)
           i+=1
        '''   
        sConcentration="Ctrl"  
        sample_ID=sample.attrib['limsid']
        sSRCPosition='1'
        SrcID='CtrlRack1'
        Concentration_org=0
        sSRCPosition='1'        
        sPoolingFraction="N/A"
        sPoolingGroup="N/A"
        
        udf_child = child.findall('udf:field',nss)
        indexQC="Fail"
        for sUDF in udf_child:
            
            if sUDF.attrib['name'] == 'Pooling Fraction':
                sPoolingFraction=sUDF.text            
            if sUDF.attrib['name'] == 'Pooling Group':
                sPoolingGroup=sUDF.text
            if sUDF.attrib['name'] == 'Pooling QC':
                indexQC=sUDF.text            
            

        
        if sample_ID not in Sample_Concentration:
            sConcentration=999
        else:
            (Concentration_org,src_position,SrcID, Sample_Name, containerID,containerName,sSize, sLibVolume,sLibConcUnit)=Sample_Concentration[sample_ID].split('__')
            sConcentration=Concentration_org
            sSRCPosition=get_phisical_position(src_position)

        
        (x,w,delta)=calculate_dilution(sConcentration,sDestConcentration, sDestVolume, sSize)
        #if w <0:
        #    w=0
        #    x=sDestConcentration
        '''    
        if float(x) < 2:
            x=2
            w=float(sDestVolume)-x
        '''     
        meta_dest_containerID=int(dest_containerID.replace("27-",""))                           
        DstID=dest_containers_arr[meta_dest_containerID]
#        print (Sample_Name)
        if dest_sample_name in Affy_Controls:
            #print (dest_sample_name+"\t"+str(Affyreagent_counter))
            SrcID=Affy_Controls[dest_sample_name]
            sample_ID=limsid+"_"+sample_ID
            if (dest_sample_name == 'CEPH1463-02'):
                sSRCPosition=9
                
            if (dest_sample_name == 'Axiom_gDNA103'):
            #if (dest_sample_name == 'Axiom gDNA103'):                  
                #sSRCPosition=str(Affyreagent_counter)
                sSRCPosition=DstID[-1]
                Affyreagent_counter +=1
                '''
                    Negative_Control w=20, x=0
                '''                
            if (dest_sample_name == 'Negative_Control'):
                w=20
                x=0            

        
        if (iVolCtrl) and (float(iVolCtrl) >0):
            w=w-delta        
        
        #print (x,w,delta)
        if float(w)<0:
            w='0'
        
        new_w='%.2f' % float(w)
        new_x='%.2f' % float(x)
        concentrationNgUl=get_ng_ul(Concentration_org, sSize)


        #if (float(Concentration_org) >= float(sThreshold)) or (dest_sample_name in Affy_Controls):
        #print(SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(w)+","+str(x)+','+well_position+','+sample_ID)

        
        
        if sRobotPosition<10:
            new_sRobotPosition="0"+str(sRobotPosition)
        else:
            new_sRobotPosition=str(sRobotPosition)
        new_DstID=DstID.replace("Dst","")
        if len(new_DstID) <2:
            new_DstID="0"+new_DstID
        
        #dest_index=DestName+'_'+str(destRobot_hash[sPoolingGroup])
        
        DstID=DestName
        sRobotPosition,sDestContainerID = destRobot_hash[sPoolingGroup]
        if sRobotPosition<10:
            newRobotPos="0"+str(sRobotPosition)
        else:
            newRobotPos=str(sRobotPosition)
        if (sSRCPosition)<10:
            newSRCPos="0"+str(sSRCPosition)
        else:
            newSRCPos=str(sSRCPosition)            
            
        dest_index=DstID+"_"+newRobotPos+"_"+SrcID+"_"+newSRCPos
        
        QCStatus="Fail"
        if sLibVolume !='N/A':
            sLibVolumeLeftOver=float(sLibVolume)-float(new_x)*float(sPoolingFraction)
            sLibVolumeRequired=float(new_x)*float(sPoolingFraction)
             
            if sLibVolumeLeftOver>=0:
                QCStatus="Pass"
            else:
                sLibVolumeRequired=float(sLibVolume)
        else:
            sLibVolumeLeftOver=-999
            sLibVolumeRequired=-999
        
        #rVolumeStatus=update_artifact_post(limsid, 'Volume QC',QCStatus, '')
        
        qcUpdateStatus="N/A"   
        ''' 
        if qcFlag=="UNKNOWN":
            qcUpdateStatus=str(update_QC_flag(limsid, QCStatus.upper() ).status_code)
            qcFlag=QC_status[QCStatus.upper()]
        '''    
        
        
        #print(str( qcUpdateStatus.status_code))
        #if (QCStatus=="Pass") or (qcFlag=="PASSED"):
        '''
        For LIbrary Norm new_w=0
        
        '''
        new_w=0
        '''
        if  (QCStatus=="Pass") and (indexQC=="Pass"):
            #if QCStatus == "Fail":
            sLibVolumeRequired=float(sLibVolume)
            r=update_artifact_post(limsid, 'Library Volume To Use (ul)',sLibVolumeRequired, '')
            sUDFArtifactUpdateStatus=str(r.status_code)
        else:
            r=update_artifact_post(limsid, 'Library Volume To Use (ul)','', '')
            sUDFArtifactUpdateStatus=str(r.status_code)            
            #sUDFArtifactUpdateStatus="N/A"
        '''
        sUDFArtifactUpdateStatus="QC_mode_Fail"
        if  (qcFlag=="PASSED"):
            #if QCStatus == "Fail":
            #sLibVolumeRequired=float(sLibVolume)
            #r=update_artifact_post(limsid, 'Library Volume To Use (ul)',sLibVolumeRequired, '')
            #sUDFArtifactUpdateStatus=str(r.status_code)
            sUDFArtifactUpdateStatus="QC_mode_Pass"            
        sOUT = sOUT + SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(new_w)+","+str(sLibVolumeRequired)+','+well_position+','+sample_ID+','
        sOUT = sOUT + str(Concentration_org)+','+sLibConcUnit+','+str(concentrationNgUl)+','+sSize+','+sLibVolume+','+sPoolingFraction+','+sPoolingGroup+','+str(sLibVolumeLeftOver)+','+QCStatus+',qc='+str(qcUpdateStatus)+' '+limsid+' updStat='+sUDFArtifactUpdateStatus+'\n'
        
        #if (QCStatus=="Pass") or (indexQC=="Pass"):
        if  (qcFlag=="PASSED"):
            #if QCStatus == "Fail":
            #sLibVolumeRequired=float(sLibVolume)
                        
            if dest_index not in dest_sort_hash:
                #dest_sort_hash[dest_index]=SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(new_w)+","+str(sLibVolumeRequired)+','+well_position+','+sample_ID
                dest_sort_hash[dest_index]=SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(new_w)+","+str(sLibVolumeRequired)
        
        if (iVolCtrl) and (float(iVolCtrl) >0):            
            sOUT = sOUT + 'CtrlRack1,1,'+DstID+','+str(sRobotPosition)+',0,'+str(delta)+','+well_position+','+sample_ID+',999\n'
            ctrl_index='CtrlRack1_'+new_sRobotPosition         
            if ctrl_index not in dest_sort_hash:
                #dest_sort_hash[ctrl_index]='CtrlRack1,1,'+DstID+','+str(sRobotPosition)+',0,'+str(delta)+','+well_position+','+sample_ID
                dest_sort_hash[ctrl_index]='CtrlRack1,1,'+DstID+','+str(sRobotPosition)+',0,'+str(delta)
        
 
 
    # print a sorted in human order 
    for key in sorted(dest_sort_hash):
        #print (dest_sort_hash[key])
        sReport +=dest_sort_hash[key]+"\n" 
    if bReports=='1':
        f_out=open(LUIDs[1]+"_log.csv","w")       
        f_out.write(sOUT)
        f_out.close()
        
    return sReport


def get_manual_well_position_from_artifacts(sXML):    
    global dest_containers_arr,Affyreagent_counter,dest_sort_hash

    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}
    pDOM = parseString( sXML )
    
    #print (sXML)
    root = ET.fromstring(sXML)
    ss=''
    dest_sort_hash={}
#    sHeader='Src ID,Src Coord,Dst ID,Dst Coord,Diluent Vol,Sample Vol,Coord,Sample Name'
    
    
#    print(sHeader)
    proj="XXX"
    #sHeader='SampleName,SrcContainerName::ContainerID,SrcWell,DstContainer Name::ContainerID,DstWell,VolSample,VolWater,VolCtrl,Sample LIMSID\n'
    sHeader='SampleName,SrcContainerName::ContainerID,SrcWell,DstContainer Name::ContainerID,DstWell,VolSample\n'
    sOUT=sHeader+",VolWater,Sample LIMSID,Conversion,Size (bp),Library Volume used (ul)"
    i=1
    Affyreagent_counter =1
    '''
     get all destination containers and assign Dst index in sorted oreder
    '''
    
    for child in root.findall('art:artifact',nss):
        sLocation=child.find('location')
        container=sLocation.find('container')
        dest_containerID=container.attrib['limsid'] 
        meta_dest_containerID=int(dest_containerID.replace("27-",""))   
        if meta_dest_containerID not in dest_containers_arr:
           dest_containers_arr[meta_dest_containerID] = ""
           
    j=1
    for contr in sorted(dest_containers_arr):
        dest_containers_arr[contr]="Dst"+str(j)
        j +=1
    
    #f_out=open(LUIDs[1]+"_log.csv","w")
    for child in root.findall('art:artifact',nss):
        #print (child)
        limsid=child.attrib['limsid']
        name = child.find('name')
        dest_sample_name=name.text
        qcFlag=child.find('qc-flag').text
        parentID=child.find('parent-process')
        sLocation=child.find('location')
        container=sLocation.find('container')
        
        pos=sLocation.find('value')
        well_position=pos.text
        #print (well_position)
        if len(well_position)==3:
            well_position=well_position.replace(':','0')
        else:
            well_position=well_position.replace(':','')
        sample= child.find('sample')
        
        metaProj=sample.attrib['limsid'][0:6]
        dest_containerID=container.attrib['limsid']
        sRobotPosition=get_phisical_position(well_position)
        '''
        commented due to dest_containers_arr has been created and sorted by ID earlier on top side 
        
        
        if dest_containerID not in dest_containers_arr:
           dest_containers_arr[dest_containerID] = "Dst"+str(i)
           i+=1
        '''   
        sConcentration="Ctrl"  
        sample_ID=sample.attrib['limsid']
        SrcID='CtrlRack1'
        Concentration_org=0
        sSRCPosition='1'
        src_position='1:1'        
        sPoolingFraction="N/A"
        sPoolingGroup="N/A"
        sQCStatus="Pass"
        udf_child = child.findall('udf:field',nss)
        indexQC="Fail"
        for sUDF in udf_child:
            if sUDF.attrib['name'] == 'Pooling Fraction':
                sPoolingFraction=sUDF.text            
            if sUDF.attrib['name'] == 'Pooling Group':
                sPoolingGroup=sUDF.text
            if sUDF.attrib['name'] == 'Pooling QC':
                indexQC=sUDF.text            
      
        
        if sample_ID not in Sample_Concentration:
            sConcentration=999
        else:
            (Concentration_org,src_position,SrcID, Sample_Name, containerIDSRC,containerNameSRC,sSize, sLibVolume,sLibConcUnit)=Sample_Concentration[sample_ID].split('__')
            sConcentration=Concentration_org
            sSRCPosition=get_phisical_position(src_position)
        
        (x,w,delta)=calculate_dilution(sConcentration,sDestConcentration, sDestVolume,sSize)
        '''
        For manual with control volume 5.8
        
        
        if float(x) < 2:
            x=2
            w=float(sDestVolume)-x        
        w=w-delta
        
        '''
        '''
        if w <0:
            w=0
            x=sDestConcentration
        '''
             
        meta_dest_containerID=int(dest_containerID.replace("27-",""))   
        sDestContName=get_container_name(dest_containerID)                        
        DstID=dest_containers_arr[meta_dest_containerID]
#        print (Sample_Name)
        if dest_sample_name in Affy_Controls:
            #print (dest_sample_name+"\t"+str(Affyreagent_counter))
            SrcID=Affy_Controls[dest_sample_name]
            sample_ID=limsid+"_"+sample_ID
            if (dest_sample_name == 'CEPH1463-02'):
                sSRCPosition=9
                
            if (dest_sample_name == 'Axiom_gDNA103'):
            #if (dest_sample_name == 'Axiom gDNA103'):                  
                #sSRCPosition=str(Affyreagent_counter)
                sSRCPosition=DstID[-1]
                Affyreagent_counter +=1
                '''
                    Negative_Control w=20, x=0
                '''                
            if (dest_sample_name == 'Negative_Control'):
                w=20
                x=0            
        
        if float(w)<0:
            w='0'
        new_w='%.2f' % float(w)
        new_x='%.2f' % float(x)
        
        concentrationNgUl=get_ng_ul(Concentration_org, sSize)
        QCStatus="Fail"
        if sLibVolume !='N/A':
            sLibVolumeLeftOver=float(sLibVolume)-float(new_x)*float(sPoolingFraction)
            sLibVolumeRequired=float(new_x)*float(sPoolingFraction)
            if sLibVolumeLeftOver>=0:
                QCStatus="Pass"
            else:
                sLibVolumeRequired=float(sLibVolume)
        else:
            sLibVolumeLeftOver=-999
            sLibVolumeRequired=-999
  
  

    
      
        
        '''
        - 'SampleName,SrcContainerName::ContainerID,SrcWell,DstContainer Name::ContainerID,DstWell,VolSample,VolWater,VolCtrl,Sample LIMSID\n'
        '''
        #sOUT = sOUT + dest_sample_name+','+SrcID+','+str(sSRCPosition)+','+DstID+','+well_position+','+str(sRobotPosition)+','+str(new_x)+","+str(new_w)+','+str(iVolCtrl)+','+sample_ID+','+str(Concentration_org)+'\n'
        if (qcFlag=="PASSED"):
            sOUT = sOUT + dest_sample_name+','+containerNameSRC+'::'+containerIDSRC+','+src_position+','+sDestContName+'::'+dest_containerID+','+well_position+','+str(sLibVolumeRequired)+","+str(new_w)+','+sample_ID+','+str(Concentration_org)+' nM,'+sSize+'\n'

        #if (float(Concentration_org) >= float(sThreshold)) or (dest_sample_name in Affy_Controls):
        #print(SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(w)+","+str(x)+','+well_position+','+sample_ID)

        
        
        if sRobotPosition<10:
            new_sRobotPosition="0"+str(sRobotPosition)
        else:
            new_sRobotPosition=str(sRobotPosition)
        new_DstID=DstID.replace("Dst","")
        if len(new_DstID) <2:
            new_DstID="0"+new_DstID
        

        
        #dest_index=new_DstID+'_'+new_sRobotPosition
        dest_index=limsid
        DstID=DestName
        sRobotPosition,sDestContainerID = destRobot_hash[sPoolingGroup] 
        well_position= sRobotPosition
        sDestContName=DestName     
         
        if sRobotPosition<10:
            newRobotPos="0"+str(sRobotPosition)
        else:
            newRobotPos=str(sRobotPosition)
        if (sSRCPosition)<10:
            newSRCPos="0"+str(sSRCPosition)
        else:
            newSRCPos=str(sSRCPosition)            
            
        dest_index=DstID+"_"+newRobotPos+"_"+SrcID+"_"+newSRCPos
        
        #if (qcFlag=="PASSED") and (indexQC=="Pass"):
        if (qcFlag=="PASSED"):
            if dest_index not in dest_sort_hash:
                #dest_sort_hash[dest_index]=SrcID+','+str(sSRCPosition)+','+DstID+','+str(sRobotPosition)+','+str(new_w)+","+str(new_x)+','+well_position+','+sample_ID
                #dest_sort_hash[dest_index]=dest_sample_name+','+SrcID+','+src_position+','+DstID+','+well_position+','+str(new_x)+","+str(new_w)+','+str(iVolCtrl)+','+sample_ID
                dest_sort_hash[dest_index]=dest_sample_name+','+containerNameSRC+'::'+containerIDSRC+','+src_position+','+sDestContName+"::"+sPoolingGroup+','+str(well_position)+','+str(sLibVolumeRequired)
        
 
 
    # print a sorted in human order 
    sSortedOUT=sHeader
    for key in sorted(dest_sort_hash):
        
        #print (dest_sort_hash[key])
        sSortedOUT += dest_sort_hash[key] +"\n"   
    #f_out.write(sOUT)
    #plates_info=print_plates_info_table()
    #f_out.write(plates_info)
    #f_out.close()
        
    return sOUT,sSortedOUT




def get_control_concentration(controlURI):
    global BASE_URI, user,psw
    #sURI=BASE_URI+'artifacts/batch/retrieve'
    #print (sURI)
    #headers = {'Content-Type': 'application/xml'}
    r = requests.get(controlURI, auth=(user, psw), verify=True)
    #print (r.content)
    rDOM = parseString( r.content )
    controlConcentration=rDOM.getElementsByTagName( "concentration" )[0].firstChild.data   
    return controlConcentration    
    



def get_sorted_containers(sXML):    
    global containers_arr

    nss ={'udf':"http://genologics.com/ri/userdefined", 'art':"http://genologics.com/ri/artifact", 'prj':"http://genologics.com/ri/project"}
    
    
    
    root = ET.fromstring(sXML)
    ss=''
    
    sHeader='Src ID\tSrc Coord\tDst ID\tDst Coord\tDiluent Vol\tSample Vol\tCoord\tSample Name'
 
    proj="XXX"
    i=1
    locContainers={}
    for child in root.findall('art:artifact',nss):
        #print (child)
        limsid=child.attrib['limsid']
        name = child.find('name')
        artifact_name=name.text
        #print (artifact_name)
        parentID=child.find('parent-process')
        sLocation=child.find('location')
        container=sLocation.find('container')
        
        pos=sLocation.find('value')
        well_position=pos.text
        #print (well_position)
        if len(well_position)==3:
            well_position=well_position.replace(':','0')
        else:
            well_position=well_position.replace(':','')
        sample= child.find('sample')
        sample_ID=sample.attrib['limsid']
        metaProj=sample.attrib['limsid'][0:6]

        
        containerID=container.attrib['limsid']
        isControlContainer=child.find('control-type')
        
        if (containerID not in locContainers) and (isControlContainer is None):
           locContainers[containerID] = str(i)
           i+=1
    
    j=1
    for contr in sorted(locContainers):
        containers_arr[contr]="Src"+str(j)
        j +=1
    
    return



def get_placement_containers(stepURI_v2):
    global user,psw, container_barcodes
    sURI=stepURI_v2 +'/placements'
    s=""
    r = requests.get(sURI, auth=(user, psw), verify=True)
    rDOM = parseString( r.content )
#    print('\n')    
#    print (r.content)
#    print('\n')
     
    i=0
    for node in rDOM.getElementsByTagName('selected-containers')[0].childNodes:
        s=node.toxml()
        ss=extract_container_ID (s)
        if (ss):
#            kk=":".join("{:02x}".format(ord(c)) for c in ss)
#            sName=get_container_name(ss)

            print (str(i)+'\tcontainerID:\t'+ss)
        i=i+1
    return
def extract_container_ID (sXML):
    container_ID='x'
    s_split=sXML.split('/')
    container_ID=s_split[len(s_split)-2].replace('"','')
    
    return container_ID


def getInnerXml(xml, tag):
    """Returns the contents inside of a tag in a given Xml tag string.

        Keyword arguments:
        xml -- The Xml tag string to extract contents from
        tag -- The tag in which to retrieve contents

    """
    tagname = '<' + tag + '.*?>'
    inXml = re.sub(tagname, '', xml)

    tagname = '</' + tag + '>'
    inXml = inXml.replace(tagname, '')

    return inXml

def getUDF( rDOM, udfname ):
    response = ""
    elements = rDOM.getElementsByTagName( "udf:field" )
    for udf in elements:
        temp = udf.getAttribute( "name" )
        if temp == udfname:
            response = getInnerXml( udf.toxml(), "udf:field" )
            break
    return response

def old_print_plates_info_table():
    ss='\n'
    sMapHeader="Container ID,Container Name,Robot Deck Position\n"
    f_mapping=open(LUIDs[2]+"_mapping.csv","w")
    for containerID in sorted(containers_arr):
        ss +=containerID+","+get_container_name(containerID)+","+containers_arr[containerID]+"\n"
    ss+="\n"
    for dest_containerID in sorted(dest_containers_arr):
        ss +=dest_containerID+","+get_container_name(dest_containerID)+","+dest_containers_arr[dest_containerID]+"\n"
    ss+="\n"    
        
    for ctrl in sorted(Affy_Controls):
        sExtra=','
        if (ctrl =="NA12878") :
        #if (ctrl =="Axiom gDNA103") :
            sExtra +=str(Affyreagent_counter-1)
            
        ss += ctrl+","+Affy_Controls[ctrl]+sExtra+"\n"
    f_mapping.write(sMapHeader)
    f_mapping.write(ss)
    f_mapping.close()
    
    return ss

def print_plates_info_table():
    ss='\n'
    f_mapping=open(LUIDs[2]+"_mapping.csv","w")
    for containerID in sorted(containers_arr):
        ss +=containerID+","+get_container_name(containerID)+","+containers_arr[containerID]+"\n"
    ss+="\n"
    '''
    for meta_dest_containerID in sorted(dest_containers_arr):
        dest_containerID="27-"+str(meta_dest_containerID)
        ss +=dest_containerID+","+get_container_name(dest_containerID)+","+dest_containers_arr[meta_dest_containerID]+"\n"
    '''
    for meta_dest_containerID in sorted(dest_containers_arr):
        dest_containerID="27-"+str(meta_dest_containerID)
        for key in sorted(destRobot_hash):
            sRobotPos,sDestContID=destRobot_hash[key]
            if sDestContID ==dest_containerID:
                ss +=dest_containerID+","+key+","+DestName+":"+str(sRobotPos)+"\n"
        
        
    ss+="\n"  
    '''      
    for ctrl in sorted(Affy_Controls):
        sExtra=','
        if (ctrl =="Axiom_gDNA103") :
        #if (ctrl =="Axiom gDNA103") :
            sExtra +=str(Affyreagent_counter-1)
            
        ss += ctrl+","+Affy_Controls[ctrl]+sExtra+"\n"
    '''
    #print(ss)
    f_mapping.write(ss)
    f_mapping.close()
    return ss  


  
def print_manual_csv(sSortedOUT):
    if sSortedOUT:
        f_csv=open(LUIDs[3]+"_for_manual.csv","w")
        f_csv.write(sSortedOUT)
        f_csv.close()
    
    return    

def get_ng_ul(snM,sSize):
    ss=-1
    if snM:
        ss=float(snM)*float(sSize)*617.9*10**-6
        
    return ss    

def get_map_io_by_process(processLuid, artifactType, outputGenerationType):
    ## get the process XML
    map_io={}
    pURI = BASE_URI + "processes/" + processLuid
    #print(pURI)
    pXML= requests.get(pURI, auth=(user, psw), verify=True)
    
    #print (pXML.content)
    pDOM = parseString( pXML.content )

    ## get the individual resultfiles outputs
    artifactsByProcess=[]
    nodes = pDOM.getElementsByTagName( "input-output-map" )
    for node in nodes:
        input = node.getElementsByTagName("input")
        iURI = input[0].getAttribute( "post-process-uri" )
        iLUID = input[0].getAttribute( "limsid" )
        output=node.getElementsByTagName("output")
        oType = output[0].getAttribute( "output-type" )
        ogType = output[0].getAttribute( "output-generation-type" )
        oLUID = output[0].getAttribute( "limsid" )
        
        new_key=iLUID+"xxx"+oLUID
        if oType == artifactType and ogType == outputGenerationType:#"PerInput":
            #if iLUID not in map_io:
            map_io[new_key]=oLUID

    return map_io

def update_QC_flag(artID, qcFlag ):
    sURI=BASE_URI+'artifacts/'+artID
    
    artXML=requests.get(sURI, auth=(user, psw), verify=True)
    
    DOM = parseString( artXML.content)    
    nodeName="qc-flag"

    if DEBUG > 2: print( DOM.toprettyxml() )
    if DOM.parentNode is None:
        isBatch = False
    else:
        isBatch = True

    newDOM = xml.dom.minidom.getDOMImplementation()
    newDoc = newDOM.createDocument( None, None, None )
#   if the node already exists, delete it
    elements = DOM.getElementsByTagName( nodeName)
    for element in elements:
        if element.toxml():
            try:
                if isBatch:
                   DOM.removeChild( element )
                else:
                        DOM.childNodes[0].removeChild( element )
            except (xml.dom.NotFoundErr, e):
                if DEBUG > 0: print( "Unable to Remove existing UDF node" )
            break

        # now add the new UDF node
    txt = newDoc.createTextNode( QC_status[qcFlag.upper()] )
    newNode = newDoc.createElement( nodeName)
    newNode.appendChild( txt )
    if isBatch:
        DOM.appendChild( newNode )
    else:
        DOM.childNodes[0].appendChild( newNode )
    #r = api.PUT(DOM.toxml(),sURI)
    #print(DOM.toxml())
    headers = {'Content-Type': 'application/xml'}
    r = requests.put(sURI, data=DOM.toxml(), auth=(user, psw), verify=True, headers=headers)
    
    return r



def update_artifact_post(artID, udfName,udfValue, udfType):
    sURI=BASE_URI+'artifacts/'+artID
    artXML=requests.get(sURI, auth=(user, psw), verify=True)
    #artXML=api.GET(sURI)
    pDOM = parseString( artXML.content)
    DOM=my_setUDF(pDOM, udfName, udfValue,udfType) 
    #r = api.PUT(DOM.toxml(),sURI)
    headers = {'Content-Type': 'application/xml'}
    r = requests.put(sURI, data=DOM.toxml(), auth=(user, psw), verify=True, headers=headers)

    return r

def my_setUDF( DOM, udfname, udfvalue,udftype ):
    
    if (udftype ==""):
        udftype="String"

    if DEBUG > 2: print( DOM.toprettyxml() )

        ## are we dealing with batch, or non-batch DOMs?
    if DOM.parentNode is None:
        isBatch = False
    else:
        isBatch = True

    newDOM = xml.dom.minidom.getDOMImplementation()
    newDoc = newDOM.createDocument( None, None, None )

        ## if the node already exists, delete it
    elements = DOM.getElementsByTagName( "udf:field" )
    for element in elements:
        if element.getAttribute( "name" ) == udfname:
            try:
                if isBatch:
                   DOM.removeChild( element )
                else:
                        DOM.childNodes[0].removeChild( element )
            except (xml.dom.NotFoundErr, e):
                if DEBUG > 0: print( "Unable to Remove existing UDF node" )

            break

        # now add the new UDF node
    txt = newDoc.createTextNode( str( udfvalue ) )
    newNode = newDoc.createElement( "udf:field" )
    newNode.setAttribute( "name", udfname )
    #newNode.setAttribute( "type", udftype )
    newNode.appendChild( txt )
    if isBatch:
        DOM.appendChild( newNode )
    else:
        DOM.childNodes[0].appendChild( newNode )

    return DOM


'''
    Start
    
'''


def main():
    if (stepURI_v2) :
        setupGlobalsFromURI(stepURI_v2)
        (sDestConcentration, sDestVolume, sControls, sThreshold, sConcentrationFrom, sTarget, iQuantity,iVolCtrl)=get_process_UDFs(ProcessID)
        #print (sDestConcentration, sDestVolume, sControls, sThreshold, sConcentrationFrom, sTarget, iQuantity)
        
        map_io=get_map_io_by_process(ProcessID, 'Analyte', 'PerInput')
        sXML=prepare_artifacts_batch_from_map_io(map_io, 'input')
        #print (sXML)
        #exit()
        #get_artifacts_array(ProcessID)
        
        

        #sXML=prepare_artifacts_batch(ArtifactsLUID)
        lXML=retrieve_artifacts(sXML)

        '''
        Sort containers A->Z
        '''
        get_sorted_containers(lXML)
        #for contr in containers_arr:
        #    print (contr, containers_arr[contr])
        
        #exit()
        get_concentration_from_artifacts(lXML)
        #print("################")
        #print (lXML)
        #print("################")
        
        
        #for sample_ID in Sample_Concentration:
        #     print (sample_ID, Sample_Concentration[sample_ID])        
        #exit()
        
                    
        if (sConcentrationFrom == "Submitted Sample"):
            get_org_samples_array(lXML)
            samplesXML=prepare_samples_batch(sampleURIs)
            retSamplesXML=retrieve_samples(samplesXML)
            
            #print (retSamplesXML)
            
            get_concentration_from_org_samples(retSamplesXML)
        
        #for sample_ID in Sample_Concentration:
         #   print (sample_ID, Sample_Concentration[sample_ID])

        #get_dest_artifacts_array(ProcessID)
        dest_sXML=prepare_artifacts_batch_from_map_io(map_io, 'output')
        #dest_sXML=prepare_artifacts_batch(destArtifactsLUID)
        
        
        if DEBUG:
            print (dest_sXML)
        dest_lXML=retrieve_artifacts(dest_sXML)

        #get_well_position_from_artifacts(dest_lXML)
        if qc=='1':
            ssReport=get_qc_well_position_from_artifacts(dest_lXML)
        else:
            ssReport=get_well_position_from_artifacts(dest_lXML)
            
        #print (ssReport)
        
        if bReports=='1':
            print (ssReport)
            print_plates_info_table()
            
            (sOUT, sSortedOUT)=get_manual_well_position_from_artifacts(dest_lXML)
    
            print_manual_csv(sSortedOUT)
        
           
       
        
if __name__ == "__main__":
    main()   
    
    